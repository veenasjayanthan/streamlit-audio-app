
import streamlit as st
from utils.translator import translate_text, speak_text, get_supported_languages
from utils.llm_handler import generate_llm_response
from utils.ocr_handler import extract_text_from_image

import speech_recognition as sr
import os, tempfile
from datetime import datetime

# -- PAGE CONFIG --
st.set_page_config(page_title="MultiLingual AI Chat", layout="centered")
st.markdown('<link rel="stylesheet" href="styles.css">', unsafe_allow_html=True)

# -- INIT SESSION --
if "history" not in st.session_state:
    st.session_state.history = []

# -- TITLE --
st.title("🌐 MultiLingual AI Chat with Voice, Image & LLM")

# -- Language Selection --
languages = get_supported_languages()
lang_name = st.selectbox("Choose Language", list(languages.values()))
lang_code = [k for k, v in languages.items() if v == lang_name][0]

# -- SECTION: Text / Voice Input --
st.markdown("### 🎤 Speak or 💬 Type Your Message")
user_input = ""
use_voice = st.toggle("Use Voice Input", value=False)

if not use_voice:
    user_input = st.text_input("Your message")
else:
    if st.button("🎙️ Start Recording"):
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            st.info("Listening...")
            audio = recognizer.listen(source, phrase_time_limit=6)
            st.success("Recorded!")

        try:
            user_input = recognizer.recognize_google(audio)
            st.write("You said:", user_input)
        except:
            st.error("Could not understand audio")

# -- MAIN TEXT/VOICE LOGIC --
if user_input:
    translated = translate_text(user_input, lang_code)
    llm_response = generate_llm_response(f"User said: {user_input}\nTranslated: {translated}")
    
    st.markdown("#### 🤖 AI Reply")
    st.write(llm_response)

    audio_path = speak_text(translated, lang_code)
    st.audio(audio_path, format="audio/mp3")

    st.session_state.history.append({
        "timestamp": datetime.now().isoformat(),
        "input": user_input,
        "translated": translated,
        "llm_response": llm_response
    })

# # -- SECTION: Image Translation --
# st.markdown("### 🖼️ Translate Text from Image")

# uploaded_file = st.file_uploader("Upload an Image (signboard, menu, etc.)", type=["jpg", "png", "jpeg"])

# if uploaded_file is not None:
#     with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as temp:
#         temp.write(uploaded_file.read())
#         temp_path = temp.name

#     st.image(temp_path, caption="Uploaded Image", use_column_width=True)

#     extracted_text = extract_text_from_image(temp_path)
#     st.markdown("**📜 Extracted Text:**")
#     st.write(extracted_text)

#     if extracted_text:
#         translated_text = translate_text(extracted_text, lang_code)
#         st.markdown("**🌐 Translated Text:**")
#         st.write(translated_text)

#         audio_path = speak_text(translated_text, lang_code)
#         st.audio(audio_path, format="audio/mp3")



from langdetect import detect

# -- SECTION: Image Translation --
st.markdown("### 🖼️ Translate Text from Image")

uploaded_file = st.file_uploader("Upload an Image (signboard, menu, etc.)", type=["jpg", "png", "jpeg"])

if uploaded_file is not None:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as temp:
        temp.write(uploaded_file.read())
        temp_path = temp.name

    # st.image(temp_path, caption="Uploaded Image", use_column_width=True)
    st.image(temp_path, caption="Uploaded Image", use_container_width=True)


    extracted_text = extract_text_from_image(temp_path)
    st.markdown("**📜 Extracted Text:**")
    st.write(extracted_text)

    if extracted_text.strip():
        try:
            # Auto-detect language
            detected_lang_code = detect(extracted_text)
            detected_lang_name = languages.get(detected_lang_code, detected_lang_code)
            st.success(f"🧭 Detected Language: {detected_lang_name} ({detected_lang_code})")

            # Translate to selected language
            translated_text = translate_text(extracted_text, lang_code, detected_lang_code)
            st.markdown("**🌐 Translated Text:**")
            st.write(translated_text)

            # Speak Translated Text
            audio_path = speak_text(translated_text, lang_code)
            st.audio(audio_path, format="audio/mp3")
        except:
            st.error("⚠️ Could not detect language or translate text.")


# -- SECTION: History Viewer --
if st.checkbox("Show Conversation History"):
    for msg in st.session_state.history:
        st.markdown(f"**🕒 {msg['timestamp']}**")
        st.write("**You:**", msg["input"])
        st.write("**Translated:**", msg["translated"])
        st.write("**AI:**", msg["llm_response"])
