
# import streamlit as st
# from utils.translator import translate_text, speak_text, get_supported_languages
# from utils.llm_handler import generate_llm_response
# from utils.audio_emotion import detect_emotion_from_voice
# from google.cloud import vision
# from langdetect import detect
# import speech_recognition as sr
# import os, tempfile
# from datetime import datetime

# # -- PAGE CONFIG --
# st.set_page_config(page_title="MultiLingual AI Chat", layout="centered")
# st.markdown('<link rel="stylesheet" href="styles.css">', unsafe_allow_html=True)

# # -- INIT SESSION --
# if "history" not in st.session_state:
#     st.session_state.history = []

# # -- TITLE --
# st.title("\U0001F310 MultiLingual AI Chat with Voice, Image, Emotion & LLM")

# # -- Language Selection --
# languages = get_supported_languages()
# lang_name = st.selectbox("Choose Language", list(languages.values()))
# lang_code = [k for k, v in languages.items() if v == lang_name][0]

# # -- SECTION: Text / Voice Input --
# st.markdown("### \U0001F3A4 Speak or \U0001F4AC Type Your Message")
# user_input = ""
# use_voice = st.toggle("Use Voice Input", value=False)

# if not use_voice:
#     user_input = st.text_input("Your message")
# else:
#     if st.button("\U0001F399️ Start Recording"):
#         recognizer = sr.Recognizer()
#         with sr.Microphone() as source:
#             st.info("Listening...")
#             audio = recognizer.listen(source, phrase_time_limit=6)
#             st.success("Recorded!")

#         try:
#             user_input = recognizer.recognize_google(audio)
#             st.write("You said:", user_input)

#             with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio_file:
#                 temp_audio_file.write(audio.get_wav_data())
#                 voice_path = temp_audio_file.name

#             emotion = detect_emotion_from_voice(voice_path)
#             st.info(f"\U0001F9E0 Detected Emotion: **{emotion}**")

#         except Exception as e:
#             st.error("Could not understand audio")
#             st.exception(e)

# # -- MAIN TEXT/VOICE LOGIC --
# if user_input:
#     translated = translate_text(user_input, lang_code)
#     llm_response = generate_llm_response(f"User said: {user_input}\nTranslated: {translated}")

#     st.markdown("#### \U0001F916 AI Reply")
#     st.write(llm_response)

#     audio_path = speak_text(translated, lang_code)
#     st.audio(audio_path, format="audio/mp3")

#     st.session_state.history.append({
#         "timestamp": datetime.now().isoformat(),
#         "input": user_input,
#         "translated": translated,
#         "llm_response": llm_response
#     })

# # -- GOOGLE CLOUD VISION OCR --
# def extract_text_from_image_vision(image_path):
#     client = vision.ImageAnnotatorClient()
#     with open(image_path, "rb") as image_file:
#         content = image_file.read()

#     image = vision.Image(content=content)
#     response = client.text_detection(image=image)
#     texts = response.text_annotations

#     if not texts:
#         return ""

#     return texts[0].description

# # -- SECTION: Image Translation --
# st.markdown("### \U0001F5BC️ Translate Text from Image")

# uploaded_file = st.file_uploader("Upload an Image (signboard, menu, etc.)", type=["jpg", "png", "jpeg"])

# if uploaded_file is not None:
#     with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as temp:
#         temp.write(uploaded_file.read())
#         temp_path = temp.name

#     st.image(temp_path, caption="Uploaded Image", use_container_width=True)

#     extracted_text = extract_text_from_image_vision(temp_path)
#     st.markdown("**\U0001F4DC Extracted Text:**")
#     st.write(extracted_text)

#     if extracted_text.strip():
#         try:
#             detected_lang_code = detect(extracted_text)
#             detected_lang_name = languages.get(detected_lang_code, detected_lang_code)
#             st.success(f"\U0001F9ED️ Detected Language: {detected_lang_name} ({detected_lang_code})")

#             translated_text = translate_text(extracted_text, lang_code, detected_lang_code)
#             st.markdown("**\U0001F310 Translated Text:**")
#             st.write(translated_text)

#             audio_path = speak_text(translated_text, lang_code)
#             st.audio(audio_path, format="audio/mp3")
#         except Exception as e:
#             st.error(f"⚠️ Could not detect or translate text: {str(e)}")

# # -- SECTION: History Viewer --
# if st.checkbox("Show Conversation History"):
#     for msg in st.session_state.history:
#         st.markdown(f"**\U0001F552 {msg['timestamp']}**")
#         st.write("**You:**", msg["input"])
#         st.write("**Translated:**", msg["translated"])
#         st.write("**AI:**", msg["llm_response"])